# PROJECT B --- PL<A>Y
## Description🎆 
![alt text](https://github.com/lindashao1220/abc2022/blob/master/projectA/Screen%20Shot%202022-10-17%20at%2021.39.42.png)

Inspired by the game Frogger, Jean and I made [pl<a>y](https://lindashao1220.github.io/abc2022/projectA%20sculpture/), a chrome extension-style game. Users play as a frog and try to avoid all the hyperlinks text on the web page to survive. The scrolling will get faster as time goes on, so BE CAREFUL and HAVE FUN.

 
## Challenges and Solutions🔥
The first challenge for me is to make the windows move in a curving way, and I choose to use the sin and cos eventually. Second, I have encountered a lot of position problems. Because first I have used the exact pixel to posit things, and this just works for a specific screen with a specific width and height. Then I change all the positions into a percentage way compared to the screen width and height. This shift makes my firework performance applied to all kinds of different-size screens. Third, to make my work a sculpture rather than an interactive performance. My [first-version work](https://lindashao1220.github.io/abc2022/projectA/) is interative. Whenever users click the button, the firework will be triggered. After I received feedback after presentation, I have changed it into a sculpture which can be automatically played every one minute itself.

Thanks for Prof.Leon's help along the way! Always provide the best way dealing all the problems I have🥰

## Shortcomings and Compromises🎇
I think the compromises I have made now is I did't succeed making the firework been played at a random time interval:((()

